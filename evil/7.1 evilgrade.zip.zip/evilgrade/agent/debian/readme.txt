This is a simple bind shell port 5555 inside a .deb package (using perl and DEBIAN/preinst bash script)

Create package
#rm seed-debian_0.3_all.deb && dpkg-deb -b seed-debian/ seed-debian_0.3_all.deb